from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('login', views.login_view, name='login'),
    path('employee/list', views.employeeList, name='employeeList'),
    path('employee/<int:employee_id>/edit', views.employeeEdit, name='employeeList'),
    path('employee/new', views.employeeNew, name='employeeNew'),
    path('employee/delete', views.employeeDelete, name='employeeDelete'),
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)